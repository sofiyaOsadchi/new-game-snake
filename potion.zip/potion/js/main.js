const ingredientList = [
    { id: 'unicorn-hair', name: 'Unicorn Hair', img: 'img/unicornhair.png' },
    { id: 'dittany-leaves', name: 'Dittany Leaves', img: 'img/dittanyleevs.png' },
    { id: 'phoenix-tears', name: 'Phoenix Tears', img: 'img/phoenixtears.png' },
    { id: 'dragon-scales', name: 'Dragon Scales', img: 'img/dragonscales.png' },
    { id: 'bat-wings', name: 'Bat Wings', img: 'img/batwings.png' },
    { id: 'mandrake-root', name: 'Mandrake Root', img: 'img/mandaraekeroot.png' },
    { id: 'gillyweed', name: 'Gillyweed', img: 'img/giliweed.png' },
    { id: 'leeches', name: 'Leeches', img: 'img/leeches.png' },
    { id: 'bezoar', name: 'Bezoar', img: 'img/bezoar.png' },
    { id: 'boomslang-skin', name: 'Boomslang Skin', img: 'img/boomslang.png' }
];

function createRandomIngredients() {
    const container = document.getElementById('ingredients');
    container.innerHTML = '';

    const shuffledIngredients = ingredientList.sort(() => 0.5 - Math.random());

    shuffledIngredients.forEach(ingredient => {
        const div = document.createElement('div');
        div.className = 'ingredient';
        div.draggable = true;
        div.id = ingredient.id;
        div.style.backgroundImage = `url(${ingredient.img})`;
        div.style.backgroundSize = 'cover';
        div.style.width = '100px';
        div.style.height = '100px';
        div.setAttribute('ondragstart', 'drag(event)');
        container.appendChild(div);
    });
}

createRandomIngredients();

function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
}

function allowDrop(event) {
    event.preventDefault();
}

function drop(event) {
    event.preventDefault();
    var data = event.dataTransfer.getData("text");
    var ingredient = document.getElementById(data);

    var cauldron = document.getElementById('cauldron');
    cauldron.appendChild(ingredient);
}
