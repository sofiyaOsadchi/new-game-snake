const ingredientList = [
    { id: 'unicorn-hair', name: 'Unicorn Hair', img: 'img/unicornhair.png' },
    { id: 'dittany-leaves', name: 'Dittany Leaves', img: 'img/dittanyleevs.png' },
    { id: 'phoenix-tears', name: 'Phoenix Tears', img: 'img/phoenixtears.png' },
    { id: 'dragon-scales', name: 'Dragon Scales', img: 'img/dragonscales.png' },
    { id: 'bat-wings', name: 'Bat Wings', img: 'img/batwings.png' },
    { id: 'mandrake-root', name: 'Mandrake Root', img: 'img/mandaraekeroot.png' },
    { id: 'gillyweed', name: 'Gillyweed', img: 'img/giliweed.png' },
    { id: 'leeches', name: 'Leeches', img: 'img/leeches.png' },
    { id: 'bezoar', name: 'Bezoar', img: 'img/bezoar.png' },
    { id: 'boomslang-skin', name: 'Boomslang Skin', img: 'img/boomslang.png' }
];

function createRandomIngredients() {
    const container = document.getElementById('ingredients');
    container.innerHTML = '';

    const shuffledIngredients = ingredientList.sort(() => 0.5 - Math.random());

    shuffledIngredients.forEach(ingredient => {
        const div = document.createElement('div');
        div.className = 'ingredient';
        div.draggable = true;
        div.id = ingredient.id;
        div.style.backgroundImage = `url(${ingredient.img})`;
        div.style.backgroundSize = 'cover';
        div.style.width = '100px';
        div.style.height = '100px';
        div.setAttribute('ondragstart', 'drag(event)');
        container.appendChild(div);
    });
}

createRandomIngredients();

function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
}

function allowDrop(event) {
    event.preventDefault();
}
function drop(event) {
    event.preventDefault();
    let data = event.dataTransfer.getData("text");
    let ingredient = document.getElementById(data);

    ingredient.style.position = 'relative';
    ingredient.style.top = 'auto';
    ingredient.style.left = 'auto';

    let cauldron = document.getElementById('cauldron');
    cauldron.appendChild(ingredient);
}


function displayRandomRecipe() {
    const randomRecipe = recipes[Math.floor(Math.random() * recipes.length)];
    document.getElementById('recipe-name').textContent = randomRecipe.name;

    const stepsList = document.getElementById('recipe-steps');
    stepsList.innerHTML = ''; // Clear previous steps
    randomRecipe.steps.forEach(step => {
        const stepItem = document.createElement('li');
        stepItem.textContent = `${step.action} ${step.ingredient || ''} ${step.duration || ''}`;
        stepsList.appendChild(stepItem);
    });
}

// Event listeners for heating and mixing buttons
document.getElementById('heat-button').addEventListener('click', () => {
    // Handle heating action
    console.log('Heating...');
});

document.getElementById('mix-button').addEventListener('click', () => {
    // Handle mixing action
    console.log('Mixing...');
});

// Display a random recipe when the page loads
document.addEventListener('DOMContentLoaded', displayRandomRecipe);


