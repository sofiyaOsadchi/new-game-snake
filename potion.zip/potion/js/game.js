function startHeating() {
    if (currentStepIndex < currentRecipe.steps.length) {
        const currentStep = currentRecipe.steps[currentStepIndex];
        if (currentStep.action === 'heat') {
            isHeating = true;
            heatStartTime = Date.now();
            document.getElementById('heating-indicator').style.display = 'block'; // Show heating indicator
            // Start timer
            const heatDuration = currentStep.duration;
            startTimer(heatDuration);
        } else {
            failGame();
        }
    }
}

function stopHeating() {
    if (isHeating) {
        const currentStep = currentRecipe.steps[currentStepIndex];
        const heatDuration = Date.now() - heatStartTime;
        if (heatDuration >= currentStep.duration) {
            currentStepIndex++;
            isHeating = false;
            document.getElementById('heating-indicator').style.display = 'none'; // Hide heating indicator
            stopTimer(); // Stop timer
            checkCompletion();
        } else {
            failGame();
        }
    }
}

function mix() {
    if (currentStepIndex < currentRecipe.steps.length) {
        const currentStep = currentRecipe.steps[currentStepIndex];
        if (currentStep.action === 'mix') {
            currentStepIndex++;
            // Add mixing animation to cauldron
            document.getElementById('cauldron-image').classList.add('mixing-animation');
            // Remove animation after a short delay
            setTimeout(() => {
                document.getElementById('cauldron-image').classList.remove('mixing-animation');
            }, 1000); // Adjust time based on animation duration
            checkCompletion();
        } else {
            failGame();
        }
    }
}

function startTimer(duration) {
    const timerElement = document.getElementById('timer');
    timerElement.style.display = 'block';
    let timeLeft = duration;
    const timer = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timer);
            timerElement.style.display = 'none';
        } else {
            timerElement.textContent = timeLeft + 's';
            timeLeft--;
        }
    }, 1000);
}

function stopTimer() {
    const timerElement = document.getElementById('timer');
    timerElement.style.display = 'none';
}
