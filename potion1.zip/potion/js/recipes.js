const recipes = [
    {
        name: "Potion of Vitality",
        ingredients: ["unicorn-hair", "gillyweed", "phoenix-tears"],
        steps: [
            { action: "add", ingredient: "unicorn-hair" },
            { action: "heat", duration: "10s" },
            { action: "add", ingredient: "gillyweed" },
            { action: "mix", duration: "5s" },
            { action: "add", ingredient: "phoenix-tears" }
        ]
    },
    {
        name: "Elixir of Strength",
        ingredients: ["dragon-scales", "bat-wings", "bezoar"],
        steps: [
            { action: "add", ingredient: "dragon-scales" },
            { action: "mix", duration: "15s" },
            { action: "add", ingredient: "bat-wings" },
            { action: "heat", duration: "20s" },
            { action: "add", ingredient: "bezoar" }
        ]
    },
    {
        name: "Memory Potion",
        ingredients: ["mandrake-root", "dittany-leaves", "leeches"],
        steps: [
            { action: "add", ingredient: "mandrake-root" },
            { action: "heat", duration: "5s" },
            { action: "add", ingredient: "dittany-leaves" },
            { action: "mix", duration: "10s" },
            { action: "add", ingredient: "leeches" }
        ]
    },
    {
        name: "Invisibility Draught",
        ingredients: ["gillyweed", "boomslang-skin", "unicorn-hair"],
        steps: [
            { action: "add", ingredient: "gillyweed" },
            { action: "mix", duration: "20s" },
            { action: "add", ingredient: "boomslang-skin" },
            { action: "heat", duration: "15s" },
            { action: "add", ingredient: "unicorn-hair" }
        ]
    },
    {
        name: "Sleeping Potion",
        ingredients: ["leeches", "bat-wings", "mandrake-root"],
        steps: [
            { action: "add", ingredient: "leeches" },
            { action: "heat", duration: "10s" },
            { action: "add", ingredient: "bat-wings" },
            { action: "mix", duration: "5s" },
            { action: "add", ingredient: "mandrake-root" }
        ]
    }
];
